%% color
blue1 = [21,151,165]/255;
blue2=[14,96,107]/255;
orange = [229,133,93]/255;
yellow = [255,194,75]/255;
purple = [12,0,100]/255;
red = [0.64,0.08,0.18];
red1=[246 111 105]/255;
green = [168,218,219]/255;
color=[red1;green;purple;orange;blue2];

SIZE=['o-';'x-';'o-';'x-';'o-';'x-';'o-'];
%% 
num_b_collect=20:10:60;
figure('position',[400,20,650,500])
clock=1;
for num_b=num_b_collect
    load(['Eq_numb',num2str(num_b),'.mat']);
    lambda_R_collect=nRIS_collect/pi/100^2;
    plot(lambda_R_collect,BlindRatio,...
    '-s','LineWidth',1.5,...
    'Color',color(clock,:),...
    'MarkerSize',4,...
    'MarkerFaceColor','w')
    hold on
    clock=clock+1;
end
clock=1;
for num_b=num_b_collect
    load(['num_b',num2str(num_b),'.mat']);
    lambda_R_collect=nRIS_collect/pi/100^2;
    plot(lambda_R_collect,BlindRatio,...
    '--o','LineWidth',1.5,...
    'Color',color(clock,:),...
    'MarkerSize',4,...
    'MarkerFaceColor','w')
    hold on
    clock=clock+1;
end
grid minor
legend('Solid: Analytical results, $\lambda_b=6.36e$-4/m$^2$',...
    'Solid: Analytical results, $\lambda_b=9.55e$-4/m$^2$',...
    'Solid: Analytical results, $\lambda_b=1.3e$-3/m$^2$',...
    'Solid: Analytical results, $\lambda_b=1.6e$-3/m$^2$',...
    'Solid: Analytical results, $\lambda_b=1.9e$-3/m$^2$',...
    'Dashed: Experimental results','Interpreter','latex',...
    'FontSize',13,'Location','northeast');
xlabel('The Density of RIS $\lambda_R$ in /m$^2$','Interpreter','latex','FontSize',15);
ylabel('Blind Area Ratio','Interpreter','latex','FontSize',15);
% xlabel('RIS密度','Interpreter','latex','FontSize',15,'Fontname','仿宋','FontWeight','bold');
% ylabel('盲区比例','Interpreter','latex','FontSize',15,'Fontname','仿宋','FontWeight','bold');
set(gca,'TickLabelInterpreter','latex','FontSize',15,'LineWidth',1.5);
xlim([0,lambda_R_collect(1,end)]);
