parameters;
%% rate
iter=1;
nRIS_collect=[1,5,7,10,30,50];%1,5,7,10,30,50
%%s
% num_b=50;
% lambda_b=num_b/pi/R^2;
% radius_BS_collect=[200];%100,150,200,250,300
% for radius_BS=radius_BS_collect
%     lambda_Y=1/pi/radius_BS^2;
%%
radius_BS=200;
lambda_Y=1/pi/radius_BS^2;
num_b_collect=[20,30,60];%10,30,40,50
for num_b=num_b_collect
    lambda_b=num_b/pi/R^2;
    RATE=zeros(size(nRIS_collect));
    RATE_d=zeros(size(nRIS_collect));
    for i=1:size(nRIS_collect,2)
        nRIS=nRIS_collect(1,i);
        lambda_R=nRIS/pi/R^2;
        for iit=1:iter
            [rate,rate_d]=Eq_rate(lambda_Y,lambda_R,lambda_b);
            RATE(1,i)=RATE(1,i)+rate/iter;
            RATE_d(1,i)=RATE_d(1,i)+rate_d/iter;
        end
    end
    figure(2)
    plot(nRIS_collect,RATE,'-^b');
    % save(['fig\rate\Pcov_final_rc',num2str(radius_BS),'_b',num2str(num_b),'.mat'],"SINR_collect","P_cov_collect","nRIS_collect");
    % save(['E:\论文撰写\RIS_deployment\multi_BS\coverage_simulation\fig3G_cov\covrBS200_b\Pcov_final_rc',num2str(radius_BS),'_b',num2str(num_b),'.mat'],"SINR_collect","P_cov_collect","nRIS_collect");
    save(['E:\论文撰写\RIS_deployment\multi_BS\coverage_simulation\fig3G_cov\rate\Eq_rate_rc',num2str(radius_BS),'_b',num2str(num_b),'.mat'],"RATE","RATE_d","nRIS_collect");
end