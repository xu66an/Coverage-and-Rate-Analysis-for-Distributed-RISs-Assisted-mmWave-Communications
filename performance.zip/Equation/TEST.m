%% main: Based on the derived formulas in the theorems
parameters;
%% cov rate
SINR_collect=[-5,0,1:2:15,20:5:50];%-5,0,1:2:15,20:5:50
iter=1;
nRIS_collect=[1,5,7,10,30,50];%1,5,7,10,30,50
%%s
num_b=50;
lambda_b=num_b/pi/R^2;
radius_BS_collect=[150,200,250];%100,150,200,250,300
for radius_BS=radius_BS_collect
    lambda_Y=1/pi/radius_BS^2;
%%
% radius_BS=200;
% lambda_Y=1/pi/radius_BS^2;
% num_b_collect=[60];%10,30,40,50
% for num_b=num_b_collect
    % lambda_b=num_b/pi/R^2;
    P_cov_collect=zeros(size(nRIS_collect,2),size(SINR_collect,2));
    for i=1:size(nRIS_collect,2)
        nRIS=nRIS_collect(1,i);
        lambda_R=nRIS/pi/R^2;
        for iit=1:iter
            [~,~,P_cov]=Pcov_allcode_radius(lambda_Y,lambda_R,lambda_b,SINR_collect);
            P_cov_collect(i,:)=P_cov_collect(i,:)+P_cov/iter;
        end
    end
    figure(2)
    plot(nRIS_collect,P_cov_collect,'-^b');
    % save(['fig\rate\Pcov_final_rc',num2str(radius_BS),'_b',num2str(num_b),'.mat'],"SINR_collect","P_cov_collect","nRIS_collect");
    save(['E:\OneDrive - zju.edu.cn\1_xuyuan\论文撰写\Performance Analysis and Deployment of\RIS_deployment_code\multi_BS\fig28G\covb50_rv\Pcov_final_rc',num2str(radius_BS),'_b',num2str(num_b),'.mat'],"SINR_collect","P_cov_collect","nRIS_collect");
end