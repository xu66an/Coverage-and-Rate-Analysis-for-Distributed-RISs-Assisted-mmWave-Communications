function [P_blind]=Blindratio(lambda_Y,lambda_R,lambda_b)
% addpath('D:\1_xuyuan\RIS_deployment\multi_BS');
parameters;
pr_los=@(xi) exp(-2*lambda_b*E_L*xi/pi);
P_R_m=1-exp(-lambda_R*integral(@(r) pr_los(r)*2*pi.*r,0,Inf));
%UE至少有一个LOS BS的概率P_L
P_L=1-exp(-lambda_Y*integral(@(r) pr_los(r)*2*pi.*r,0,Inf));
% 至少有一个RIS辅助的NLOS BS的概率
P_blind=1-(P_L+(1-P_L)*P_R_m);
end