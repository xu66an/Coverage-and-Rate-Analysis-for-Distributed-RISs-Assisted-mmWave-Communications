nRIS_collect=[1,3,5,10,15,25,35,45,55];
radius_BS_collect=[300];%100,150,200,300
Bandwidth=200;%MHz
int_upbound=log2(50+1)*Bandwidth;
for radius_BS=radius_BS_collect
    load(['Pcov_final_rc',num2str(radius_BS),'_b20.mat']);    
    rate=zeros(size(nRIS_collect));
    for i=1:size(nRIS_collect,2)
        nRIS=nRIS_collect(1,i);
        p1=polyfit(SINR_collect,P_cov_collect(i,:),10);
        fit_p1=matlabFunction(poly2sym(p1));
        x0=0:5:50;
        y0=fit_p1(x0);
        figure(5)
        plot(SINR_collect,P_cov_collect(i,:),'b');
        hold on
        plot(x0,y0,'red');
        rate(1,i)=integral(@(x) fit_p1(2.^(x./Bandwidth)-1),0,int_upbound);
    end
    figure(1)
    plot(nRIS_collect,rate);
    hold on
    save(['rate_rc',num2str(radius_BS),'.mat'],"nRIS_collect","rate")
end

