%% color
blue = [0.00,0.45,0.74];
orange = [0.85,0.33,0.10];
yellow = [0.93,0.69,0.13];
purple = [0.49,0.18,0.56];
red = [0.64,0.08,0.18];
black = [0.15,0.15,0.15];
green = [0.4660 0.6740 0.1880];
color=[blue;orange;yellow;purple;red;green;black];
SIZE=['o-';'x-';'o-';'x-';'o-';'x-';'o-'];
%% 
radius_BS_collect=50:50:300;
figure('position',[400,100,650,500])
clock=1;
for radius_BS=radius_BS_collect
    load(['association_final_rc',num2str(radius_BS),'.mat']);
    blind_ratio=1-(P_Ad_collect+P_AI_collect);
    lambda_R_collect=nRIS_collect/pi/100^2;
    plot(lambda_R_collect,blind_ratio,...
    SIZE(clock,:),'LineWidth',1.5,...
    'Color',color(clock,:),...
    'MarkerSize',6.7,...
    'MarkerFaceColor','w')
    hold on
    clock=clock+1;
end
legend('$r_v$=50m','$r_v$=100m','$r_v$=150m','$r_v$=200m','$r_v$=250m','$r_v$=300m','Interpreter','latex','FontSize',18,'Location','northeast');
% xlabel('The density of RIS $\lambda_R$ in /m$^2$','Interpreter','latex','FontSize',15);
% ylabel('Blind Area Ratio','Interpreter','latex','FontSize',15);
xlabel('RIS密度','Interpreter','latex','FontSize',15,'Fontname','仿宋','FontWeight','bold');
ylabel('盲区比例','Interpreter','latex','FontSize',15,'Fontname','仿宋','FontWeight','bold');
set(gca,'TickLabelInterpreter','latex','FontSize',17,'LineWidth',1.5);
xlim([0,lambda_R_collect(1,end)]);
