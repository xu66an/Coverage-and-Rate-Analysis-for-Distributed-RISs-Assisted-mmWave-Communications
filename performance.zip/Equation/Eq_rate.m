function [rate,rate_d]=Eq_rate(lambda_Y,lambda_R,lambda_b)
% addpath('D:\1_xuyuan\RIS_deployment\multi_BS');
parameters;
pr_los=@(xi) exp(-2*lambda_b*E_L*xi/pi);
int1=@(x) arrayfun(@(x) integral(@(r) pr_los(r)*2*pi.*r,0,x),x);
f_r0=@(x) lambda_R.*pr_los(x)*2*pi.*x.*exp(-lambda_R.*int1(x));
f_xi0=@(x) lambda_Y.*pr_los(x)*2*pi.*x.*exp(-lambda_Y.*int1(x));
P_R_m=1-exp(-lambda_R*integral(@(r) pr_los(r)*2*pi.*r,0,Inf));
%UE至少有一个LOS BS的概率P_L
P_L=1-exp(-lambda_Y*integral(@(r) pr_los(r)*2*pi.*r,0,Inf));
% % 至少有一个RIS辅助的NLOS BS的概率
% P_N_R=1-exp(-lambda_Y*integral(@(r) (1-pr_los(r))*P_R_m*2*pi.*r,0,Inf));
% F_eta0_r0
inner=@(xi) lambda_Y*P_R_m.*xi.*(1-pr_los(xi)); %P_r_m改成P_N_R  
% inner=@(xi) lambda_Y*P_R_m.*xi;
theta_min=0;%@(r,xi) acos(min((r.^2+xi.^2)./(2.*r.*xi),1));%0-pi 2*
theta_max=@(r,xi,x) acos(min(max((r.^4+r.^2.*xi.^2-x.^2)./(2*r.^3.*xi),-1),1));
% F_eta00=@(x) 1-exp(-integral2(@(r,xi) inner(xi).*f_r0(r)*2.*(theta_max(r,xi,x)),0,Inf,0,radius*10));
F_eta_r=@(r,x) 1-exp(-integral(@(xi) inner(xi)*2.*(theta_max(r,xi,x)),0,Inf));
F_eta00=@(x) integral(@(r) arrayfun(@(r) f_r0(r).*F_eta_r(r,x),r),0,Inf);

% %f_eta0
% eta=sym('eta');
% F_eta0_sym=F_eta0(eta);
% f_eta0=matlabFunction(diff(F_eta0_sym));

%fit
xx_max=round(5e5/(lambda_R*pi*R^2));
xx_step=xx_max/100;
xx_c=0:xx_step:xx_max;
ans_F_eta0=zeros(size(xx_c));
for i=1:size(xx_c,2)
    ans_F_eta0(1,i)=F_eta00(xx_c(1,i));
end
% save(['Feta0_nRIS',num2str(nRIS),'_rBS',num2str(radius_BS),'.mat'],'xx_c','ans_F_eta0');
p=polyfit(xx_c,ans_F_eta0,15);
y0=polyval(p,xx_c);
figure(1);plot(xx_c,ans_F_eta0);hold on
plot(xx_c,y0);
syms eta;
F_eta0_sym=poly2sym(p,eta);
f_eta0=matlabFunction(diff(F_eta0_sym));
F_eta0=matlabFunction(F_eta0_sym);
f_eta0=@(eta) abs(f_eta0(eta)).*(eta<xx_max)+0.*(eta>=xx_max);
F_eta0=@(eta) F_eta0(eta).*(eta<xx_max)+ans_F_eta0(end).*(eta>=xx_max);

tilde_fxi0=@(x) f_xi0(x).*(1-F_eta0((10^Alpha*N_R^2)^(1/Beta)*x)); 
tilde_feta0=@(eta) arrayfun(@(eta) f_eta0(eta).*integral(@(x) f_xi0(x),(10^Alpha*N_R^2)^(-1/Beta)*eta,Inf),eta);

int_los_sym=@(xi0) arrayfun(@(xi0) integral(@(rr) lambda_Y.*pr_los(rr)*2*pi.*rr.*rr.^(-Beta),xi0,10000),xi0);
% int_los_sym=@(xi0) lambda_Y*pi*10000^2*P_L.*arrayfun(@(xi0) integral(@(rr) rr.^(-Beta).*2.*rr/10000^2,xi0,10000),xi0);
% % int_nlos=@(xi) arrayfun(@(xi) integral2(@(r,theta) (xi.^2+r.^2-2.*xi.*r.*cos(theta)).^(-Beta/2).*r.^(-Beta).*(2*r/radius^2),0,radius,0,2*pi),xi);
% % int_nlos_sym=@(xi0) arrayfun(@(xi0) integral(@(xi) int_nlos(xi)*lambda_Y.*(1-pr_los(xi))*P_R_m.*xi,xi0,Inf),xi0);
% int_nlos_sym=@(xi0) arrayfun(@(xi0) integral3(@(r,theta,xi) (xi.^2+r.^2-2.*xi.*r.*cos(theta)).^(-Beta/2).*r.^(-Beta).*(2*r/radius^2).*(1-pr_los(xi)).*xi*lambda_Y*P_R_m,0,radius,0,2*pi,xi0,Inf),xi0);
int_nlos_sym=fun_nlos(lambda_Y,lambda_R,lambda_b);
IF_d_L=@(xi) BS_power*10^Alpha*int_los_sym(xi)*E_hv(N_BS,N_u);
IF_d_N=@(xi) BS_power*10^(2*Alpha).*int_nlos_sym(xi)*E_hv(N_BS,N_R)*E_hv(N_R,N_u);
rate_d=integral(@(xi) log2(1+BS_power*10^Alpha*N_BS*N_u./(xi.^Beta)./(Noise+IF_d_L(xi)+IF_d_N(xi))).*tilde_fxi0(xi),0,Inf);
    
IF_I_L=@(eta0) BS_power*(10^Alpha)*E_hv(N_BS,N_u).*int_los_sym((10^Alpha*N_R^2)^(-1/Beta).*eta0);
IF_I_N=@(eta0) BS_power*10^(2*Alpha).*E_hv(N_BS,N_R)*E_hv(N_R,N_u).*int_nlos_sym((10^Alpha*N_R^2)^(-1/Beta).*eta0);
rate_r=integral(@(eta0) log2(1+BS_power*10^(2*Alpha)./(eta0.^Beta)*N_BS*N_R^2*N_u./(Noise+IF_I_L(eta0)+IF_I_N(eta0))).*f_eta0(eta0),0,Inf);
rate_r_0=integral(@(eta0) log2(1+BS_power*10^(2*Alpha)./(eta0.^Beta)*N_BS*N_R^2*N_u./(Noise+IF_I_L(eta0)+IF_I_N(eta0))).*tilde_feta0(eta0),0,Inf);%f_eta0换成tilde_feta0
rate=rate_d+(1-P_L)*rate_r+rate_r_0;
end


function y=E_hv(N_t,N_r)
    psi_t=4*0.886/N_t;
    psi_r=4*0.886/N_r;
    m_t=1/(sin(3*pi/2/sqrt(N_t)))^2;
    m_r=1/(sin(3*pi/2/sqrt(N_r)))^2;
    y=psi_t*psi_r/(2*pi)^2*N_t*N_r+psi_t*(2*pi-psi_r)/(2*pi)^2*N_t*m_r+(2*pi-psi_t)*psi_r/(2*pi)^2*m_t*N_r+(2*pi-psi_t)*(2*pi-psi_r)/(2*pi)^2*m_t*m_r;
end
