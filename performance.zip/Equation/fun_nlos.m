%与lambda_b和lambda_R,lambda_Y有关
function f_nlos=fun_nlos(lambda_Y,lambda_R,lambda_b)
parameters;
radius=10000;
pr_los=@(xi) exp(-2*lambda_b*E_L*xi/pi);
% int_nlos1=@(xi) arrayfun(@(xi) integral2(@(r,theta) (xi.^2+r.^2-2.*xi.*r.*cos(theta)).^(-Beta/2).*r.^(-Beta).*(2*r/radius^2),0,radius,0,2*pi),xi);
int_nlos1=@(xi0) arrayfun(@(xi0) integral3(@(r,theta,xi) (xi.^2+r.^2-2.*xi.*r.*cos(theta)).^(-Beta/2).*r.^(-Beta).*(2*r/radius^2).*xi.*(1-pr_los(xi))*lambda_Y,0,radius,0,2*pi,xi0,radius),xi0); %*lambda_Y.*(1-pr_los(xi))
% int_nlos=@(xi0) int_nlos1(xi0)*P_R_m;
% int_nlos_sym=@(xi0) integral(@(xi) int_nlos1(xi).*(1-pr_los(xi)).*xi,xi0,Inf);
% int_nlos_sym2=@(xi0) int_nlos_sym(xi0)*lambda_Y*P_R_m;
max_xi0=3000;
sample_xi0=0:100:max_xi0;
y=int_nlos1(sample_xi0);
p=polyfit(sample_xi0,y,15);
% figure;plot(sample_xi0,y,'g');hold on
% y0=polyval(p,sample_xi0);
% plot(sample_xi0,y0,'b');
syms x
f_nlos=matlabFunction(poly2sym(p,x));
f_nlos=@(x) f_nlos(x).*(x<max_xi0)+y(end).*(x>=max_xi0);
% save(['int_nlos_b',num2str(num_b),'_rBS',num2str(radius_BS),'.mat'],"int_nlos");
end