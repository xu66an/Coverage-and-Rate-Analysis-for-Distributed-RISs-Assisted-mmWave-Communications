function [P_Ad,P_AI,P_cov]=Pcov_allcode_radius(lambda_Y,lambda_R,lambda_b,SINR_collect)
% addpath('D:\1_xuyuan\RIS_deployment\multi_BS');
parameters;
radius=10000;
pr_los=@(xi) exp(-2*lambda_b*E_L*xi/pi);
int1=@(x) arrayfun(@(x) integral(@(r) pr_los(r)*2*pi.*r,0,x),x);
f_r0=@(x) lambda_R.*pr_los(x)*2*pi.*x.*exp(-lambda_R.*int1(x));
f_xi0=@(x) lambda_Y.*pr_los(x)*2*pi.*x.*exp(-lambda_Y.*int1(x));
P_R_m=1-exp(-lambda_R*integral(@(r) pr_los(r)*2*pi.*r,0,Inf));
% Probability that UE has at least one LOS BS P_L
P_L=1-exp(-lambda_Y*integral(@(r) pr_los(r)*2*pi.*r,0,Inf));
% Probability of having at least one RIS-assisted NLOS BS
% P_N_R=1-exp(-lambda_Y*integral(@(r) (1-pr_los(r))*P_R_m*2*pi.*r,0,Inf));
% F_eta0_r0
inner=@(xi) lambda_Y*P_R_m.*xi.*(1-pr_los(xi)); %P_r_m改成P_N_R  
% inner=@(xi) lambda_Y*P_R_m.*xi;
theta_min=0;%@(r,xi) acos(min((r.^2+xi.^2)./(2.*r.*xi),1));%0-pi 2*
theta_max=@(r,xi,x) acos(min(max((r.^4+r.^2.*xi.^2-x.^2)./(2*r.^3.*xi),-1),1));
% F_eta00=@(x) 1-exp(-integral2(@(r,xi) inner(xi).*f_r0(r)*2.*(theta_max(r,xi,x)),0,Inf,0,radius*10));
F_eta_r=@(r,x) 1-exp(-integral(@(xi) inner(xi)*2.*(theta_max(r,xi,x)),0,Inf));
F_eta00=@(x) integral(@(r) arrayfun(@(r) f_r0(r).*F_eta_r(r,x),r),0,Inf);

% %f_eta0
% eta=sym('eta');
% F_eta0_sym=F_eta0(eta);
% f_eta0=matlabFunction(diff(F_eta0_sym));

%fit
xx_max=round(5e5/(lambda_R*pi*R^2));
xx_step=xx_max/100;
xx_c=0:xx_step:xx_max;
ans_F_eta0=zeros(size(xx_c));
for i=1:size(xx_c,2)
    ans_F_eta0(1,i)=F_eta00(xx_c(1,i));
end
% save(['Feta0_nRIS',num2str(nRIS),'_rBS',num2str(radius_BS),'.mat'],'xx_c','ans_F_eta0');
p=polyfit(xx_c,ans_F_eta0,15);
y0=polyval(p,xx_c);
figure(1);plot(xx_c,ans_F_eta0);hold on
plot(xx_c,y0);
syms eta;
F_eta0_sym=poly2sym(p,eta);
f_eta0=matlabFunction(diff(F_eta0_sym));
F_eta0=matlabFunction(F_eta0_sym);
f_eta0=@(eta) abs(f_eta0(eta)).*(eta<xx_max)+0.*(eta>=xx_max);
F_eta0=@(eta) F_eta0(eta).*(eta<xx_max)+ans_F_eta0(end).*(eta>=xx_max);


P_Ad=integral(@(xi) (1-F_eta0((10^Alpha*N_R^2)^(1/Beta)*xi)).*f_xi0(xi),0,Inf);
P_AI=P_L*integral(@(xi) F_eta0((10^Alpha*N_R^2)^(1/Beta)*xi).*f_xi0(xi),0,Inf)+(1-P_L).*P_R_m;

tilde_fxi0=@(x) f_xi0(x).*(1-F_eta0((10^Alpha*N_R^2)^(1/Beta)*x)); 
tilde_feta0=@(eta) arrayfun(@(eta) f_eta0(eta).*integral(@(x) f_xi0(x),(10^Alpha*N_R^2)^(-1/Beta)*eta,Inf),eta);

% rr=sym('rr','positive');
% xi0=sym('xi0','positive');
% in_Q1=lambda_Y*exp(-2*lambda_b*E_L*rr/pi)*2*pi.*rr/rr^Beta;
% int_los_sym=matlabFunction(int(in_Q1,xi0,Inf));
% in_Q2=lambda_Y*(1-exp(-2*lambda_b*E_L*rr/pi))*P_R_m*2*pi*rr/( N_R^2*rr^Beta);
% int_nlos_sym=matlabFunction(int(in_Q2,xi0,Inf));
int_los_sym=@(xi0) arrayfun(@(xi0) integral(@(rr) lambda_Y*exp(-2*lambda_b*E_L*rr/pi)*2*pi.*rr./rr.^Beta,xi0,Inf),xi0);
% % int_nlos=@(xi) arrayfun(@(xi) integral2(@(r,theta) (xi.^2+r.^2-2.*xi.*r.*cos(theta)).^(-Beta/2).*r.^(-Beta).*(2*r/radius^2),0,radius,0,2*pi),xi);
% % int_nlos_sym=@(xi0) arrayfun(@(xi0) integral(@(xi) int_nlos(xi)*lambda_Y.*(1-pr_los(xi))*P_R_m.*xi,xi0,Inf),xi0);
% int_nlos_sym=@(xi0) arrayfun(@(xi0) integral3(@(r,theta,xi) (xi.^2+r.^2-2.*xi.*r.*cos(theta)).^(-Beta/2).*r.^(-Beta).*(2*r/radius^2).*(1-pr_los(xi)).*xi*lambda_Y*P_R_m,0,radius,0,2*pi,xi0,Inf),xi0);
int_nlos_sym=fun_nlos(lambda_Y,lambda_R,lambda_b);
P_cov=zeros(size(SINR_collect));
for j=1:size(SINR_collect,2)
    SINR=SINR_collect(1,j);
    T=db2pow(SINR);
    Q1=@(xi) exp(-1/(N_BS*N_u)*T*int_los_sym(xi)*E_hv(N_BS,N_u).*xi.^Beta);
    Q2=@(xi) exp(-1/(N_BS*N_u)*T*10^Alpha.*xi.^Beta.*int_nlos_sym(xi)*E_hv(N_BS,N_R)*E_hv(N_R,N_u));
    Pcov_d=integral(@(xi) exp(-T*Noise/(N_BS*N_u*BS_power*10^Alpha)*xi.^Beta).*Q1(xi).*Q2(xi).*tilde_fxi0(xi),0,Inf);
    % Q3=@(eta0,x1) exp(-T./(N_BS*N_R*10^Alpha.*x1)*E_hv(N_BS,N_u).*eta0.^Beta.*int_los_sym((10^Alpha*N_R^2)^(-1/Beta).*eta0));
    % Q4=@(eta0,x1) exp(-T./(N_BS*N_R*10^Alpha.*x1)*E_hv(N_BS,N_R)*E_hv(N_R,N_u).*eta0.^Beta.*int_nlos_sym((10^Alpha*N_R^2)^(-1/Beta).*eta0));
    % f_h_r0=@(x1) N_R*N_u*exp(-N_R*N_u*x1);
    % Pcov_r=integral2(@(eta0,x1) exp(-T*Noise./(N_BS*N_R*BS_power*10^(2*Alpha)*x1).*eta0.^Beta).*Q3(eta0,x1).*Q4(eta0,x1).*f_h_r0(x1).*tilde_feta0(eta0),0,Inf,0,Inf);
    F_hshr=@(z0) arrayfun(@(z0) 1/(N_BS*N_R^2*N_u)*integral2(@(x,z) 1./x.*exp(-x/(N_BS*N_R)-z./x/(N_R*N_u)),0,Inf,z0,Inf),z0);
    Q3=@(eta0) T./(10^Alpha)*E_hv(N_BS,N_u).*eta0.^Beta.*int_los_sym((10^Alpha*N_R^2)^(-1/Beta).*eta0);
    Q4=@(eta0) T.*eta0.^Beta*E_hv(N_BS,N_R)*E_hv(N_R,N_u).*int_nlos_sym((10^Alpha*N_R^2)^(-1/Beta).*eta0);
    Pcov_r=integral(@(eta0) F_hshr(T*Noise./(BS_power*10^(2*Alpha)).*eta0.^Beta+Q3(eta0)+Q4(eta0)).*f_eta0(eta0),0,Inf);
    Pcov_r_0=integral(@(eta0) F_hshr(T*Noise./(BS_power*10^(2*Alpha)).*eta0.^Beta+Q3(eta0)+Q4(eta0)).*tilde_feta0(eta0),0,Inf); %f_eta0换成tilde_feta0
    % PP_cov=Pcov_d+(1-P_L)*P_N_R*Pcov_r+Pcov_r_0;
    P_cov(1,j)=Pcov_d+(1-P_L)*Pcov_r+Pcov_r_0;
end
end


function y=E_hv(N_t,N_r)
    psi_t=4*0.886/N_t;
    psi_r=4*0.886/N_r;
    m_t=1/(sin(3*pi/2/sqrt(N_t)))^2;
    m_r=1/(sin(3*pi/2/sqrt(N_r)))^2;
    y=psi_t*psi_r/(2*pi)^2*N_t*N_r+psi_t*(2*pi-psi_r)/(2*pi)^2*N_t*m_r+(2*pi-psi_t)*psi_r/(2*pi)^2*m_t*N_r+(2*pi-psi_t)*(2*pi-psi_r)/(2*pi)^2*m_t*m_r;
end


% sample_xx=0:250:50000;
% ans_F_eta0=zeros(size(sample_xx));
% for ii=1:size(sample_xx,2)
%     xx=sample_xx(1,ii);
%     ans_F_eta0(1,ii)=integral(@(r) f_r0(r).*F_eta_r(r,xx),0,Inf);
% end
% figure(1)
% % plot(x0,y0,'blue');
% % hold on
% plot(sample_xx,ans_F_eta0,'green');
% % 
% sample_xx=0:250:50000;
% sample_r0=generate_rnd(f_r0,num_MC);
% ans_F_eta0=zeros(size(sample_xx));
% for ii=1:size(sample_xx,2)
%     xx=sample_xx(1,ii);
% %     xx=10000;
%     sum_int_r0=0;
%     for jj=1:num_MC
%         r0=sample_r0(1,jj);        
%         F_eta0_r0=inner1(r0,xx);
%         sum_int_r0=sum_int_r0+F_eta0_r0;
%     end
%     ans_F_eta0(1,ii)=sum_int_r0/num_MC;
% end
% 
% p=polyfit(sample_xx,ans_F_eta0,15);
% 
% x0=0:10:50000;
% y0=polyval(p,x0);
% figure(1)
% plot(x0,y0,'blue');
% hold on
% plot(sample_xx,ans_F_eta0,'green');
% title("F_eta0");
% 
% eta=sym('eta');
% F_eta0_sym=poly2sym(p,eta);
% f_eta0=matlabFunction(diff(F_eta0_sym));
% f_eta0=@(eta) abs(f_eta0(eta)).*(eta<50000)+0.*(eta>=50000);
% F_eta0=matlabFunction(F_eta0_sym);
% F_eta0=@(eta) F_eta0(eta).*(eta<50000)+1.*(eta>=50000);

% %direct
% sum_d=0;
% for ii=1:num_MC
%     r0=sample_tilde_r0(1,ii);
%     Id_L=E_hv(N_BS,N_u)*double(subs(int_los_sym,r0))*BS_power*10^Alpha;
%     Id_N=E_hv(N_BS,N_R)*E_hv(N_R,N_u)*double(subs(int_nlos_sym,r0))*BS_power*10^(2*Alpha);
%     sum_d=sum_d+exp(-1/(N_BS*N_u)*T*(Noise+Id_L+Id_N)*r0^Beta/BS_power/10^Alpha);
% end
% Pcov_d=sum_d/num_MC;
% %reflect
% sum_r=0;
% for ii=1:num_MC
%     eta0=sample_tilde_eta0(1,ii);
%     sample_ht=exprnd(N_R*N_u,1,num_MC);
%     in_min_Q34=(10^Alpha*N_R^2)^(-1/Beta)*eta0;
%     sum_r1=0;
%     Ir_L=E_hv(N_BS,N_u)*double(subs(int_los_sym,in_min_Q34))*BS_power*10^(2*Alpha);
%     Ir_N=E_hv(N_BS,N_R)*E_hv(N_R,N_u)*double(subs(int_nlos_sym,in_min_Q34))*BS_power*10^(2*Alpha);
%     for jj=1:num_MC
%         x1=sample_ht(1,jj);
%         sum_r1=sum_r1+exp(-1/(N_BS*N_R)*T*(Noise+Ir_L+Ir_N)*eta0^Beta/(BS_power*10^(2*Alpha)*x1));
%     end
%     a_sumr1=sum_r1/num_MC;
%     sum_r=sum_r+a_sumr1;
% end
% Pcov_r=sum_r/num_MC;
